# Codelabs for Material Components for Android (MDC-Android)

[Material Components for Android](https://material.io/components/android/) are modular and customizable UI
components that implement Material Design. This repo houses the source for the [Building Beautiful
Apps Faster](https://codelabs.developers.google.com/codelabs/mdc-android/index.html) codelab.
